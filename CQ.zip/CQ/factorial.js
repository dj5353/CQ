var fact = function(n){
    fact = 1;
    for(var i = n ; i>1 ; i--){
        fact = fact*i;
    }
    return fact;
}
console.log(fact());

//Time -> O(n)
