is_prime = function(n){
    flag = 0;
    if(n<2){
        console.log("Number is not prime");
    }
    for(var i = 2; i <n / 2 ;i++){
        if(n%i == 0){
            flag += 1;
            break;
        }
    }
    if(flag == 0){
        console.log("Number is Prime");
    }
    else{
        console.log("Number is not Prime");
    }
}

is_prime(3)