var leap_year = function(year){
    if(year%4 == 0){
        if(year%100 == 0){
            if(year%400 == 0){
                console.log("Year is a Leap Year");
            }
            else{
                console.log("Year is not a Leap Year");
            }
        }
        else{
            console.log("Year is a Leap Year");
        }
    }
    else{
        console.log("Year is not a Leap Year");
    }
}
leap_year(2021);