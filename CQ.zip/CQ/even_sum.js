var even_sum  = function(arr){
    sum = 0;
    arr.forEach(element => {
        if(element%2 == 0){
            sum += element;
        }
    });
    console.log(sum);
}
even_sum([1,2,3,4,5,6,7,8,9,10]);