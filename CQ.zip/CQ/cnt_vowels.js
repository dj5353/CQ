cnt_vowels = function(str){
    cnt = 0;
        for(var i = 0 ; i<str.length;i++){
            if(str [i] == 'a'|| str [i] == 'a'|| str [i] == 'u'|| str [i] == 'o'|| str [i] == 'i'|| str [i] == 'e'){
                cnt++;
            }
        }
        return cnt;
}   
console.log(cnt_vowels("divit"));



