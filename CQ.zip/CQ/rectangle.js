function area(length,breadth){
    return length*breadth;
}
a = area(12,12);
console.log(a);