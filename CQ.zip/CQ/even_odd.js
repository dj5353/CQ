var odd_even = function(arr){
    cnt_even = 0;
    cnt_odd = 0;
    for(let i = 0 ; i < arr.length ; i++){ //O(n))
        if(arr[i]%2 == 0){
            cnt_even += 1;
        }
        else{
            cnt_odd += 1; 
        }
    }
    console.log(`${ cnt_even } are Even and ${ cnt_odd } are odd out of ${ arr.length } elements in array`);
}

odd_even([2,5,31,10,6,4,3,2,6,7])

//time -> O(n)
//space => 