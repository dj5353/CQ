//For each

// var array_sum = function(arr){
//     sum = 0;
//     arr.forEach(element => {
//         sum = sum + element;
//     });
//     return sum;
// }
// console.log(array_sum([1,2,3,4,5,6,7,8,9,10]))


//for loop

array_sum = function(arr){
    sum = 0;
    for(var i  = 0 ;i < arr.length ; i++){
        sum += arr[i];
    }
    return sum;
}
console.log(array_sum([1,2,3,4,5,6,7,8,9,10]))